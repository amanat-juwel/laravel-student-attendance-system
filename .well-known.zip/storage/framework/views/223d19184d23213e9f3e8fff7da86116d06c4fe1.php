<?php if(Session::has('success')): ?>
<div class="alert alert-success" id="success">
    <?php echo e(Session::get('success')); ?>

    <?php
    Session::forget('success');
    ?>
</div>
<?php endif; ?>
<?php if(Session::has('update')): ?>
<div class="alert alert-warning" id="update">
    <?php echo e(Session::get('update')); ?>

    <?php
    Session::forget('update');
    ?>
</div>
<?php endif; ?>
<?php if(Session::has('delete')): ?>
<div class="alert alert-danger" id="delete">
    <?php echo e(Session::get('delete')); ?>

    <?php
    Session::forget('delete');
    ?>
</div>
<?php endif; ?>