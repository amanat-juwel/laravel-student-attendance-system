

<?php $__env->startSection('template'); ?>
<!-- Content Header -->
<section class="content-header">
    <h1>STUDENT</h1>
    <ol class="breadcrumb">
        <li class="active">Dashboard</li>
        <li class="active">Student</li>
        <li class="active">Create</li>
    </ol>
</section>
<!-- End Content Header -->
<!-- Main content -->
<div class="row">
    <div class="col-md-8">
        <section class="content">
            <div class="panel panel-default">
                <div class="panel-body">
                    <div class="row">
                        <div class="col-md-12">
                            <form class="form" action="<?php echo e(route('students.store')); ?>" method="post" enctype="multipart/form-data">
                                <?php echo e(csrf_field()); ?>

                                <div class="form-group">
                                    <label for="">Metric Id</label>
                                    <input autocomplete="OFF" type="text" name="metric_id" placeholder="Metric Id" required="" class="form-control input-sm" value="<?php echo e(old('metric_id')); ?>"/>
                                    <?php if($errors->has('metric_id')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('metric_id')); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <label for="">Name</label>
                                    <input autocomplete="OFF" type="text" name="name" placeholder="Name"  class="form-control input-sm" value="<?php echo e(old('name')); ?>"/>
                                    <?php if($errors->has('name')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                                    <?php endif; ?>
                                </div>
                               
                                <div class="form-group">
                                    <label for="">Student Image</label>
                                    <input type="file" name="student_image" placeholder="" class="form-control input-sm" />
                                    <?php if($errors->has('student_image')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('student_image')); ?></span>
                                    <?php endif; ?>
                                </div> 
                       
                                <div class="form-group">
                                    <label for="">Date of birth</label>
                                    <input  autocomplete="OFF" type="text" id="datepicker" value="<?php echo e(old('dob')); ?>" name="dob" id="" class="form-control input-sm"/>
                                    <?php if($errors->has('dob')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('dob')); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <label for="">Parent</label>
                                    <select name="parent_id" id="input" class="form-control select2" required="required">
	                                    <option value="">Select </option>
                                        <?php $__currentLoopData = $parents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($parent->id); ?>" <?php if(Null !== old('parent_id')): ?> <?php if($parent->id==old('parent_id')): ?> selected <?php endif; ?> <?php endif; ?>>Father : <?php echo e($parent->father); ?> | Mother : <?php echo e($parent->mother); ?> | Mobile no : <?php echo e($parent->mobile_no); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="">Class</label>
                                    <select name="class_id" id="input" class="form-control select2" required="required">
                                        <option value="">Select </option>
                                        <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($data->id); ?>" <?php if(Null !== old('class_id')): ?> <?php if($data->id==old('class_id')): ?> selected <?php endif; ?> <?php endif; ?>><?php echo e($data->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="">Section</label>
                                    <select name="section_id" id="input" class="form-control select2" required="required">
                                        <option value="">Select </option>
                                        <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($data->id); ?>" <?php if(Null !== old('section_id')): ?> <?php if($data->id==old('section_id')): ?> selected <?php endif; ?> <?php endif; ?>><?php echo e($data->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="">Roll</label>
                                    <input autocomplete="OFF" type="text" name="roll" placeholder="Roll"  class="form-control input-sm" value="<?php echo e(old('roll')); ?>" required="" />
                                    <?php if($errors->has('roll')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('roll')); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <label for="">Van</label>
                                    <select name="van_id" id="input" class="form-control select2" >
                                        <option value="">Select </option>
                                        <?php $__currentLoopData = $vans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($data->id); ?>" <?php if(Null !== old('van_id')): ?> <?php if($data->id==old('van_id')): ?> selected <?php endif; ?> <?php endif; ?>><?php echo e($data->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <input type="submit" class="btn btn-success" value="Save"/>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Main Content -->
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>