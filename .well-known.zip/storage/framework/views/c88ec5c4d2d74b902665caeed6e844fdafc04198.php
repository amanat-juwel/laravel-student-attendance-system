<?php $__env->startSection('template'); ?>
<!-- Content Header -->
<section class="content-header">
    <div class="row">
        <div class="col-md-6">
        <h2> <i class="fa fa-users"></i>  PARENT</h2>
        </div>
        <div class="col-md-6">
        <a href="<?php echo e(route('parentmodel.index')); ?>" class="btn btn-success-outline btn-success pull-right"> <i class="fa fa-user"></i> All Parent</a>
        </div>
    </div>
   
   
</section>
<!-- End Content Header -->
<!-- Main content -->
<div class="row">
    <div class="col-md-6">
        <section class="content">
            <div class="panel panel-default">
                <div class="panel-body">
                    <div class="row">
                        <div class="col-md-12">
                            <form  action="<?php echo e(route('parentmodel.update',$parent->id)); ?>" method="POST">
                            <?php echo method_field('PUT'); ?>
                            <?php echo e(csrf_field()); ?>

                                <div class="form-group">
                                    <label for="">Father name</label>
                                    <input autocomplete="OFF" type="text" name="father" placeholder="Father name" required="" class="form-control input-sm" value="<?php echo e($parent->father); ?>"/>
                                    <?php if($errors->has('father')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('father')); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <label for="">Mother name</label>
                                    <input autocomplete="OFF" type="text" name="mother" placeholder="Mother name" required="" class="form-control input-sm" value="<?php echo e($parent->mother); ?>"/>
                                    <?php if($errors->has('mother')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('mother')); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <label for="">Address</label>
                                    <textarea name="address" placeholder="Enter address" id="input" class="form-control" rows="3" required="required" value="<?php echo e($parent->address); ?>"><?php echo e($parent->address); ?></textarea>
                                    <?php if($errors->has('address')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('address')); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <label for="">Mobile no</label>
                                    <input autocomplete="OFF" type="text" name="mobile_no" placeholder="Mobile no" required="" class="form-control input-sm" value="<?php echo e($parent->mobile_no); ?>"/>
                                    <?php if($errors->has('mobile_no')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('mobile_no')); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <label for="">Email</label>
                                    <input autocomplete="OFF" type="email" name="email" placeholder="Email" required="" class="form-control input-sm" value="<?php echo e($parent->email); ?>"/>
                                    <?php if($errors->has('email')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <label for="">Occupation</label>
                                    <input autocomplete="OFF" type="occupation" name="occupation" placeholder="occupation" required="" class="form-control input-sm" value="<?php echo e($parent->occupation); ?>"/>
                                    <?php if($errors->has('occupation')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('occupation')); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <input type="submit" class="btn btn-success btn-sm" value="Update"/>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Main Content -->
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>