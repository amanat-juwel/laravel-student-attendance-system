       
<?php $__env->startSection('template'); ?>

<section class="content-header">
    <h1>
        Metric Id Report
    </h1>
    <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li class="active">Report</li>
        <li class="active">Metric Id</li>
    </ol>
</section>



<section class="content">

    <?php if(isset($metricIdLists)): ?>
    <div class="panel panel-default">
        <div class="panel-body">
            <input class="form-control" id="myInput" type="text" placeholder="Search..">
                        <br>
            <table class="table" width="100%">
                <thead>
                    <tr>
                        <th>Metric ID</th>
                        <th>Type</th>
                    </tr>
                </thead>

                <tbody id="myTable">
                    <?php $__currentLoopData = $metricIdLists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($data->metric_id); ?></td>
                        <td><?php echo e($data->type); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php endif; ?>

</section>

 <script>
$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>