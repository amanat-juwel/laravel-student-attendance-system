 
<?php $__env->startSection('template'); ?>
<!-- Content Header -->
<section class="content-header">
    <h1>STUDENT</h1>
    <ol class="breadcrumb">
        <li>
            <a href="#"><i class="fa fa-dashboard"></i>Dashboard</a>
        </li>
        <li class="active">Student</li>
    </ol>
</section>
<!-- End Content Header -->
<!-- Main content -->
<section class="content">
    <div class="row">
        <div class="col-md-12">
            <?php echo $__env->make('partials.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <div class="col-md-12">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    TODAYS ABSENT STUDENT
                </div>
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="table-bordered datatable" id="" width="100%">
                            <thead>
                                <tr>
                                    <th height="25">Srl</th>
                                    <th>Metric Id.</th>
                                    <th>Name</th>
                                    <th class="text-center">Parent</th>
                                    <th>DOB (Y-m-d)</th>
                                    <th>Image</th>
                                    <th>Academic</th>
                                 
                                </tr>
                            </thead>
                            <tbody>
                                <?php $srl = 0; ?>
                                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $flag = 0; ?>
                                    <?php $__currentLoopData = $attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $attData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($data->id == $attData->student_id): ?>
                                            <?php $flag = 1; break; ?>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($flag != 1): ?>
                                    <tr>
                                        <td><?php echo e(++$srl); ?></td>
                                        <td><?php echo e($data->metric_id); ?></td>
                                        <td><?php echo e($data->name); ?></td>
                                        <td>
                                            <span>Father : <?php echo e($data->father); ?> </span><br>
                                            <span>Mother : <?php echo e($data->mother); ?> </span><br>
                                            <span>Mobile no : <?php echo e($data->mobile_no); ?> </span>
                                        </td>
                                        <td><?php echo e($data->dob); ?></td>
                                        <td>
                                            <img src="<?php echo e(asset($data->image)); ?>" height="50px" width="50px"/>
                                        </td>
                                        <td>
                                            <span class="text-red">Class: <?php echo e($data->class); ?></span><br>
                                            <span class="text-blue">Section: <?php echo e($data->section); ?></span><br>
                                            <span class="text-red">Roll: <?php echo e($data->roll); ?></span><br>
                                            <span class="text-blue">Van: <?php if(isset($data->van)): ?><?php echo e($data->van); ?> <?php else: ?> --- <?php endif; ?></span>
                                        </td>
                                     
                                    </tr>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- End Main Content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>