

<?php $__env->startSection('template'); ?>
<!-- Content Header -->
<section class="content-header">
    <h1>TEACHER</h1>
    <ol class="breadcrumb">
        <li class="active">Dashboard</li>
        <li class="active">Teacher</li>
        <li class="active">Create</li>
    </ol>
</section>
<!-- End Content Header -->
<!-- Main content -->
<div class="row">
    <div class="col-md-8">
        <section class="content">
            <div class="panel panel-default">
                <div class="panel-body">
                    <div class="row">
                        <div class="col-md-12">
                            <form class="form" action="<?php echo e(route('teachers.store')); ?>" method="post" enctype="multipart/form-data">
                                <?php echo e(csrf_field()); ?>

                                <div class="form-group">
                                    <label for="">Metric Id</label>
                                    <input autocomplete="OFF" type="text" name="metric_id" placeholder="Metric Id" required="" class="form-control input-sm" value="<?php echo e(old('metric_id')); ?>"/>
                                    <?php if($errors->has('metric_id')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('metric_id')); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <label for="">Name</label>
                                    <input autocomplete="OFF" type="text" name="name" placeholder="Name"  class="form-control input-sm" value="<?php echo e(old('name')); ?>"/>
                                    <?php if($errors->has('name')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <label for="">Mobile [<span class="text-danger">Number must start with 88; Total 13 Digits; Ex: 8801716998877</span>]</label>
                                    <input autocomplete="OFF" type="text" name="mobile_no" placeholder="" required="" class="form-control input-sm" pattern="^(?:\+?88)?01[15-9]\d{8}$" title="Number must start with 88; Total 13 Digits; Ex: 8801716998877" value="<?php echo e(old('mobile_no')); ?>"/>
                                    <?php if($errors->has('mobile_no')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('mobile_no')); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <label for="">Designation</label>
                                    <input autocomplete="OFF" type="text" name="designation" placeholder=""  class="form-control input-sm" value="<?php echo e(old('designation')); ?>"/>
                                    <?php if($errors->has('designation')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('designation')); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <label for="">Email</label>
                                    <input autocomplete="OFF" type="text" name="email" placeholder=""  class="form-control input-sm" value="<?php echo e(old('email')); ?>"/>
                                    <?php if($errors->has('email')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <label for="">Address</label>
                                    <input autocomplete="OFF" type="text" name="address" placeholder=""  class="form-control input-sm" value="<?php echo e(old('address')); ?>"/>
                                    <?php if($errors->has('address')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('address')); ?></span>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="form-group">
                                    <label for="">Other Contact Name</label>
                                    <input autocomplete="OFF" type="text" name="other_contact_name" placeholder=""  class="form-control input-sm" value="<?php echo e(old('other_contact_name')); ?>"/>
                                    <?php if($errors->has('other_contact_name')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('other_contact_name')); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <label for="">Relation with Other Contact </label>
                                    <select name="other_contact_type" id="input" class="form-control select2" >
                                        <option value="">Select </option>
                                        <option value="Father" <?php if(Null !== old('other_contact_type')): ?> <?php if("Father"==old('other_contact_type')): ?> selected <?php endif; ?> <?php endif; ?>>Father</option>
                                        <option value="Husband" <?php if(Null !== old('other_contact_type')): ?> <?php if("Husband"==old('other_contact_type')): ?> selected <?php endif; ?> <?php endif; ?>>Husband</option>
                                        <option value="Mother" <?php if(Null !== old('other_contact_type')): ?> <?php if("Mother"==old('other_contact_type')): ?> selected <?php endif; ?> <?php endif; ?>>Mother</option>
                                        <option value="Other" <?php if(Null !== old('other_contact_type')): ?> <?php if("Other"==old('other_contact_type')): ?> selected <?php endif; ?> <?php endif; ?>>Other</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="">Other Contact Mobile No</label>
                                    <input autocomplete="OFF" type="text" name="other_contact_mobile_no" placeholder=""  class="form-control input-sm" value="<?php echo e(old('other_contact_mobile_no')); ?>"/>
                                    <?php if($errors->has('other_contact_mobile_no')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('other_contact_mobile_no')); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <label for="">Teacher Image</label>
                                    <input type="file" name="teacher_image" placeholder="" class="form-control input-sm" />
                                    <?php if($errors->has('teacher_image')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('teacher_image')); ?></span>
                                    <?php endif; ?>
                                </div> 
                                <div class="form-group">
                                    <label for="">Class</label>
                                    <select name="class_id" id="input" class="form-control select2" required="required">
                                        <option value="">Select </option>
                                        <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($data->id); ?>" <?php if(Null !== old('class_id')): ?> <?php if($data->id==old('class_id')): ?> selected <?php endif; ?> <?php endif; ?>><?php echo e($data->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="">Section</label>
                                    <select name="section_id" id="input" class="form-control select2" required="required">
                                        <option value="">Select </option>
                                        <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($data->id); ?>" <?php if(Null !== old('section_id')): ?> <?php if($data->id==old('section_id')): ?> selected <?php endif; ?> <?php endif; ?>><?php echo e($data->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <input type="submit" class="btn btn-success" value="Save"/>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Main Content -->
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>