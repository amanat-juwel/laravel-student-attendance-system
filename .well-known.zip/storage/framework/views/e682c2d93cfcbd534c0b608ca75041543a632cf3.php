 
<?php $__env->startSection('template'); ?>
<!-- Content Header -->
<section class="content-header">
    <h1>CLASS</h1>
    <ol class="breadcrumb">
        <li>
            <a href="<?php echo e(url('/')); ?>"><i class="fa fa-dashboard"></i>Dashboard</a>
        </li>
        <li class="active">Class</li>
    </ol>
</section>
<!-- End Content Header -->
<!-- Main content -->
<section class="content">
    <div class="row">
        <div class="col-md-12">
            <?php echo $__env->make('partials.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <div class="col-md-8">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    <a class="btn btn-info btn-sm" data-toggle="modal" href='#addModal'><i class="fa fa-plus"></i> Add new</a>
                </div>
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="table-bordered datatable" id="" width="100%">
                            <thead>
                                <tr>
                                    <th height="25">Srl</th>
                                    <th> Id.</th>
                                    <th>Name</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e(++$key); ?></td>
                                        <td><?php echo e($data->id); ?></td>
                                        <td><?php echo e($data->name); ?></td>
                                        <td>
                                            <div class="flex">
                                                <button type="button" class="btn btn-primary btn-xs btnEdit"><i class="fa fa-edit"></i> Edit</button>
                                                <form action="<?php echo e(url('/classmodel/'.$data->id)); ?>" method="post">
                                                    <?php echo method_field('DELETE'); ?> <?php echo e(csrf_field()); ?>

                                                    <button class="btn btn-danger btn-xs"  onclick="return confirm('Are you sure you want to delete this item?');"  >
                                                        <i class="fa fa-trash-o" aria-hidden="true"></i> Delete
                                                    </button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- End Main Content -->


<div class="modal fade" id="addModal">
    <div class="modal-dialog">
        <div class="modal-content">
            <form class="form" action="<?php echo e(route('classmodel.store')); ?>" method="POST">
                <?php echo e(csrf_field()); ?>

                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title"><i class="fa fa-plus"></i> Add </h4>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="">Name</label>
                        <input autocomplete="OFF" type="text" name="name" placeholder="Name" required="required" class="form-control input-sm" value="<?php echo e(old('name')); ?>" />
                        <?php if($errors->has('name')): ?>
                        <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary" id="btnSubmit">Save changes</button>
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </form>
        </div>
    </div>
</div>



<div class="modal fade" id="editModal">
    <div class="modal-dialog">
        <div class="modal-content">
            <form class="form editForm" action="" method="POST">
                <?php echo method_field('PUT'); ?>
                <?php echo e(csrf_field()); ?>

                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title"><i class="fa fa-edit"></i> Edit </h4>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="">Name</label>
                        <input autocomplete="OFF" type="text" name="name" placeholder="Name" required="" class="form-control input-sm" id="editName" />
                        <?php if($errors->has('name')): ?>
                        <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary" id="btnSubmit">Update</button>
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </form>
        </div>
    </div>
</div>


<script type="text/javascript">
    
   $(function(){

        $('.btnEdit').click(function(){
            var id   = $(this).closest('tr').find('td:eq(1)').text() ;
            var name = $(this).closest('tr').find('td:eq(2)').text() ;
            $("#editModal").modal('show') ;
            $("#editName").val(name) ;
            $('.editForm').attr('action','<?php echo e(url('/classmodel')); ?>/'+id) ;
        })
   })

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>