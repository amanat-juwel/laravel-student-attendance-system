<?php $__env->startSection('template'); ?>
<!-- Content Header -->
<section class="content-header">
    <h1>MEMBER</h1>
    <ol class="breadcrumb">
        <li>
            <a href="#"><i class="fa fa-dashboard"></i>Dashboard</a>
        </li>
        <li class="active">Member</li>
        <li class="active">Create</li>
    </ol>
</section>
<!-- End Content Header -->
<!-- Main content -->
<div class="row">
    <div class="col-md-8">
        <section class="content">
            <div class="panel panel-default">
                <div class="panel-body">
                    <div class="row">
                        <div class="col-md-12">
                            <form class="form" action="<?php echo e(route('members.store')); ?>" method="post">
                                <?php echo e(csrf_field()); ?>


                                <div class="form-group">
                                    <label for="">Name</label>
                                    <input autocomplete="OFF" type="text" name="name" placeholder="Name" required="" class="form-control input-sm" value="<?php echo e(old('name')); ?>"/>
                                    <?php if($errors->has('name')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <label for="">Father</label>
                                    <input autocomplete="OFF" type="text" name="father" placeholder=""  class="form-control input-sm" value="<?php echo e(old('father')); ?>"/>
                                    <?php if($errors->has('father')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('father')); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <label for="">Mother</label>
                                    <input autocomplete="OFF" type="text" name="mother" placeholder=""  class="form-control input-sm" value="<?php echo e(old('mother')); ?>"/>
                                    <?php if($errors->has('mother')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('mother')); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <label for="">Address</label>
                                    <input autocomplete="OFF" type="text" name="address" placeholder=""  class="form-control input-sm" value="<?php echo e(old('address')); ?>"/>
                                    <?php if($errors->has('address')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('address')); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <label for="">Mobile [<span class="text-danger">Number start with 88; Total 13 Digits; Ex: 8801716998877</span>]</label>
                                    <input autocomplete="OFF" type="text" name="mobile_no" placeholder="" required="" class="form-control input-sm" pattern="^(?:\+?88)?01[15-9]\d{8}$" title="Number start with 88; Total 13 Digits; Ex: 8801716998877" value="<?php echo e(old('mobile_no')); ?>"/>
                                    <?php if($errors->has('mobile_no')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('mobile_no')); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <label for="">Position</label>
                                    <input autocomplete="OFF" type="text" name="position" placeholder=""  class="form-control input-sm" value="<?php echo e(old('position')); ?>"/>
                                    <?php if($errors->has('position')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('position')); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <input type="submit" class="btn btn-success" value="Save"/>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Main Content -->
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>