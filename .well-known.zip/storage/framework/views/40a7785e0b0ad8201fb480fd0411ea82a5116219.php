<?php $__env->startSection('template'); ?>
<!-- Content Header -->
<section class="content-header">
    <h1>Staff</h1>
    <ol class="breadcrumb">
        <li class="active">Dashboard</li>
        <li class="active">Staff</li>
        <li class="active">Edit</li>
    </ol>
</section>
<!-- End Content Header -->
<!-- Main content -->
<div class="row">
    <div class="col-md-8">
        <section class="content">
            <div class="panel panel-default">
                <div class="panel-body">
                    <div class="row">
                        <div class="col-md-12">
                            <form class="form" action="<?php echo e(url('/staffs/'.$staff->id)); ?>" method="post">
                                <?php echo method_field('PUT'); ?>
                                <?php echo e(csrf_field()); ?>

                                <div class="form-group">
                                    <label for="">Metric Id</label>
                                    <input autocomplete="OFF" type="text" name="metric_id" placeholder="Metric Id" required="" class="form-control input-sm" value="<?php echo e($staff->metric_id); ?>"/>
                                    <?php if($errors->has('metric_id')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('metric_id')); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <label for="">Name</label>
                                    <input autocomplete="OFF" type="text" name="name" placeholder="Name" required="" class="form-control input-sm" value="<?php echo e($staff->name); ?>"/>
                                    <?php if($errors->has('name')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <label for="">Father</label>
                                    <input autocomplete="OFF" type="text" name="father" placeholder=""  class="form-control input-sm" value="<?php echo e($staff->father); ?>"/>
                                    <?php if($errors->has('father')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('father')); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <label for="">Mother</label>
                                    <input autocomplete="OFF" type="text" name="mother" placeholder=""  class="form-control input-sm" value="<?php echo e($staff->mother); ?>"/>
                                    <?php if($errors->has('mother')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('mother')); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <label for="">Address</label>
                                    <input autocomplete="OFF" type="text" name="address" placeholder=""  class="form-control input-sm" value="<?php echo e($staff->address); ?>"/>
                                    <?php if($errors->has('address')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('address')); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <label for="">Mobile</label>
                                    <input autocomplete="OFF" type="text" name="mobile_no" placeholder="" required="" class="form-control input-sm" value="<?php echo e($staff->mobile_no); ?>"/>
                                    <?php if($errors->has('mobile_no')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('mobile_no')); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <label for="">Position</label>
                                    <input autocomplete="OFF" type="text" name="position" placeholder=""  class="form-control input-sm" value="<?php echo e($staff->position); ?>"/>
                                    <?php if($errors->has('position')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('position')); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <input type="submit" class="btn btn-warning" value="Update"/>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Main Content -->
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>