       
<?php $__env->startSection('template'); ?>

<section class="content-header">
    <h1>
        Teacher's Attendance Report
    </h1>
    <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li class="active">Attendance Report</li>
        <li class="active">Teacher's</li>
    </ol>
</section>



<section class="content">
    <div class="panel panel-default">
        <div class="panel-body">
            <form class="form" action="<?php echo e(url('report/teacher/single')); ?>" name="myForm" id="date_form" method="post">
                <?php echo csrf_field(); ?>

                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="" class="col-sm-4 control-label">Teacher</label>
                        <div class="col-sm-12">
                        <select name="teacher_id" class="form-control select2" required>
                            <option value="">--- Choose ---</option>
                                <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($data->id); ?>" <?php if(isset($teacher)): ?> <?php if($teacher->id == $data->id): ?> selected <?php endif; ?> <?php endif; ?> ><?php echo e($data->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        </div>
                    </div>    
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        <label for="">From</label>
                        <input type="text" id="datepicker" autocomplete="off" name="start_date" id="start_date" class="form-control input-sm" <?php if(isset($start_date)): ?> value="<?php echo e($start_date); ?>"<?php endif; ?>  required/>
                    </div>
                </div>    
                <div class="col-md-2">
                    <div class="form-group">
                         <label for="">To</label>
                         <input type="text" id="datepicker2" autocomplete="off" name="end_date" id="end_date" class="form-control input-sm" <?php if(isset($end_date)): ?> value="<?php echo e($end_date); ?>"<?php endif; ?> required onchange='if(this.value != "") { this.form.submit(); }'/>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                         <br>
                         <input type="submit"  class="btn btn-success btn-sm" value="Submit" />
                    </div>
                </div>
            </form>    
                 <div class="col-md-2">
                    <div class="form-group">
                    <br>
                    <?php if(isset($start_date)): ?>
                    <br>
                    <a class="btn btn-warning btn-xs pull-right" href="<?php echo e(url('/report/teacher/single/print/'.$teacher->id.'/'.$start_date.'/'.$end_date)); ?>" target="_blank">Print/Download as PDF</a>     
                    <?php endif; ?>
                    </div>
                </div> 
      
        </div>
    </div>
    
    
    <?php if(isset($start_date)): ?>
    <div class="panel panel-default">
        <div class="panel-body">
            <table class="table" width="100%">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>In</th>
                        <th>Out</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__currentLoopData = $attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e(date('M j,Y', strtotime($data->date))); ?></td>
                        <td><?php echo e(date('H:i a', strtotime($data->in_time))); ?></td>
                        <td><?php echo e(date('H:i a', strtotime($data->out_time))); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php endif; ?>

</section>

<script type="text/javascript">

$(document).ready(function () {
    $("#start_date").change(function () {
       $('#end_date').val('');
    });
});  
  
</script>  
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>