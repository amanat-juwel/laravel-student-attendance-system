<?php $__env->startSection('template'); ?>

<section class="content">
    <div class="row">
        <div class="col-lg-3 col-xs-6">
            <h1>Welcome</h1>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>