       
<?php $__env->startSection('template'); ?>

<section class="content-header">
    <h1>
        Student's Attendance Report
    </h1>
    <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li class="active">Attendance Report</li>
        <li class="active">Student's</li>
    </ol>
</section>

<section class="content">
    <div class="panel panel-default">
        <div class="panel-body">
            <form class="form" action="<?php echo e(url('report/class-section')); ?>" name="myForm" id="date_form" method="post">
                <?php echo csrf_field(); ?>

                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="" class="col-sm-4 control-label">Class</label>
                        <div class="col-sm-12">
                        <select name="class_id" class="form-control select2" required>
                            <option value="">--- Choose ---</option>
                                <?php $__currentLoopData = $class_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($data->id); ?>" <?php if(isset($class_id)): ?> <?php if($class_id == $data->id): ?> selected <?php endif; ?> <?php endif; ?> ><?php echo e($data->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        </div>
                    </div>    
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="" class="col-sm-4 control-label">Section</label>
                        <div class="col-sm-12">
                        <select name="section_id" class="form-control select2" required>
                            <option value="">--- Choose ---</option>
                                <?php $__currentLoopData = $section_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($data->id); ?>" <?php if(isset($section_id)): ?> <?php if($section_id == $data->id): ?> selected <?php endif; ?> <?php endif; ?> ><?php echo e($data->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        </div>
                    </div>    
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        <label for="">Date</label>
                        <input type="text" id="datepicker" autocomplete="off" name="date" id="date" class="form-control input-sm" <?php if(isset($date)): ?> value="<?php echo e($date); ?>"<?php endif; ?>  required onchange='if(this.value != "") { this.form.submit(); }'/>
                    </div>
                </div>    
                <div class="col-md-2">
                    <div class="form-group">
                         <br>
                         <input type="submit"  class="btn btn-success btn-sm" value="Submit" />
                    </div>
                </div>
            </form>    
                 <div class="col-md-2">
                    <div class="form-group">
                    <br>
                    <?php if(isset($date)): ?>
                    <br>
                    <a class="btn btn-warning btn-xs pull-right" href="<?php echo e(url('/report/class-section/print/'.$class_id.'/'.$section_id.'/'.$date)); ?>" target="_blank">Print/Download as PDF</a>     
                    <?php endif; ?>
                    </div>
                </div> 
      
        </div>
    </div>
    
    <?php if(isset($date)): ?>
    <div class="panel panel-default">
        <div class="panel-body">
            <table class="table table-striped" width="100%">
                <thead>
                    <tr>
                        <th colspan="3" class="text-center">DATE: [<?php echo e(date('M j,Y', strtotime($date))); ?>]</th>
                    </tr>
                    <tr>
                        <th>Student</th>
                        <th>In</th>
                        <th>Out</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__currentLoopData = $attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($data->student_name); ?></td>
                        <td><?php echo e(date('H:i a', strtotime($data->in_time))); ?></td>
                        <td><?php echo e(date('H:i a', strtotime($data->out_time))); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php endif; ?>
</section>

<script type="text/javascript">

$(document).ready(function () {
    $("#start_date").change(function () {
       $('#end_date').val('');
    });
});  
  
</script>  
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>